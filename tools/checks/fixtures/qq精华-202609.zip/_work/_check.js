
(function(){
  var qEl=document.getElementById('q'), hitEl=document.getElementById('hit');
  var items=[].slice.call(document.querySelectorAll('.item'));
  function run(){
    var s=(qEl.value||'').trim().toLowerCase(), n=0;
    for(var i=0;i<items.length;i++){
      var it=items[i];
      var ok=(!s||it.textContent.toLowerCase().indexOf(s)>=0);
      it.style.display=ok?'':'none';
      if(ok){n++;}
    }
    hitEl.textContent=s?(n+' 条匹配'):'';
  }
  qEl.addEventListener('input',run);
  document.addEventListener('keydown',function(e){
    if(e.key==='/' && document.activeElement!==qEl){e.preventDefault();qEl.focus();}
  });
  var links=[].slice.call(document.querySelectorAll("aside a")), heads=[].slice.call(document.querySelectorAll("h1[id]"));
  function spy(){var k=0;heads.forEach(function(h,i){if(h.getBoundingClientRect().top<=120)k=i;});
    links.forEach(function(a,i){a.classList.toggle("on",i===k);});}
  addEventListener("scroll",spy,{passive:true});spy();
})();
