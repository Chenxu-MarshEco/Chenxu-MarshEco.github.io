# -*- coding: utf-8 -*-
"""把本月精华图片拼成一张带序号的接触印相，便于一眼核对"""
import os
import json
from PIL import Image, ImageDraw

ROOT = r"E:\dsh work\qq精华-202609"
BASE = os.path.join(ROOT, "images", "752855970")
PICD = os.path.join(BASE, "图片")
chat = json.load(open(os.path.join(BASE, "_chatshots.json"), encoding="utf-8"))

files = sorted(os.listdir(PICD))
COLS, CW, CH = 3, 460, 380
rows = (len(files) + COLS - 1) // COLS
sheet = Image.new("RGB", (COLS * CW, rows * (CH + 26)), "white")
d = ImageDraw.Draw(sheet)
for i, f in enumerate(files):
    x, y = (i % COLS) * CW, (i // COLS) * (CH + 26)
    im = Image.open(os.path.join(PICD, f)).convert("RGB")
    im.thumbnail((CW - 10, CH - 10), Image.LANCZOS)
    sheet.paste(im, (x + 5, y + 24))
    n = f.split("_")[0]
    sc = (chat.get(n) or {}).get("score", "?")
    d.text((x + 6, y + 6), "#%s  score=%s  %s" % (n, sc, os.path.splitext(f)[1]), fill=(200, 0, 0))
    d.rectangle([x, y, x + CW - 1, y + CH + 24], outline=(210, 210, 210))
out = os.path.join(ROOT, "_work", "接触印相_2026年9月.png")
sheet.save(out)
print("已生成 %s  %dx%d  %d 张" % (out, sheet.width, sheet.height, len(files)))
print()
print("=== 每张图的 OCR 行 ===")
for f in files:
    n = f.split("_")[0]
    v = chat.get(n) or {}
    print("#%s  score=%d  is_chat=%s  %s" % (n, v.get("score", -1), v.get("is_chat"), f[:70]))
    for l in (v.get("lines") or [])[:14]:
        print("      " + l[:70])
