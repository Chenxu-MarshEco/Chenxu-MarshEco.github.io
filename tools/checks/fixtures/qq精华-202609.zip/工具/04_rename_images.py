# -*- coding: utf-8 -*-
"""04 重命名：按规格把图片改名成「编号_时间_文字内容（或 OCR 提取的图中文本全文）.ext」
   - 去非法字符、压缩空白、最长 110 字
   - ASCII 括号 → 全角（避免破坏 Markdown/HTML 链接）
   - 同步更新 _urlmap.json
"""
import json
import os
import re
import datetime

ROOT = r"E:\dsh work\qq精华-202609"
GID = "752855970"
BASE = os.path.join(ROOT, "images", GID)
UM = os.path.join(BASE, "_urlmap.json")
CHAT = os.path.join(BASE, "_chatshots.json")

urlmap = json.load(open(UM, encoding="utf-8"))
chat = json.load(open(CHAT, encoding="utf-8"))
recs = json.load(open(os.path.join(ROOT, "源数据_2026年9月.json"), encoding="utf-8"))["records"]

BAD = re.compile(r'[\\/:*?"<>|\r\n\t]')
NOISE = re.compile(r'^[\d\s:：./|()（）\[\]【】\-+·、]+$')


def slug(s, n=110):
    s = BAD.sub(" ", str(s or ""))
    s = s.replace("(", "（").replace(")", "）")
    s = re.sub(r"\s+", " ", s).strip(" ｜.")
    s = s[:n].rstrip(" ｜.")
    return s or "无文本"


def full_text(idx, rec_text):
    """有正文用正文；纯图片则该图 OCR 全文（多行用 ｜ 连接）"""
    if rec_text and rec_text.strip() not in ("", "[图片]"):
        return rec_text
    return "｜".join(ocr_lines(idx, 8))


def ocr_lines(idx, n=8):
    """OCR 行去噪：丢纯符号行、丢短的无中文行（水印、键盘字母、KDA 数字）"""
    lines = (chat.get(idx) or {}).get("lines") or []
    cjk = re.compile(r"[\u4e00-\u9fff]")
    keep = []
    for l in lines:
        s = l.strip()
        if len(s) < 2 or NOISE.match(s):
            continue
        if not cjk.search(s) and len(s) <= 14:
            continue
        keep.append(s)
    return keep[:n]


done = 0
renamed = {}
for r in recs:
    idx = "%03d" % r["index"]
    try:
        ts = datetime.datetime.strptime(r["time"], "%Y-%m-%d %H:%M:%S").strftime("%Y%m%d-%H%M")
    except Exception:
        ts = "00000000-0000"
    label = slug(full_text(idx, r.get("text") or ""))
    for n, u in enumerate(r.get("images") or []):
        rel = urlmap.get(u)
        if not rel:
            continue
        old = os.path.join(ROOT, rel.replace("/", os.sep))
        if not os.path.exists(old):
            continue
        ext = os.path.splitext(old)[1].lower()
        suffix = "" if len(r.get("images") or []) == 1 else "_%d" % (n + 1)
        newname = "%s_%s_%s%s%s" % (idx, ts, label, suffix, ext)
        newpath = os.path.join(os.path.dirname(old), newname)
        if os.path.abspath(old) != os.path.abspath(newpath):
            if os.path.exists(newpath):
                newname = "%s_%s_%s_%s%s%s" % (idx, ts, label[:96], (u[-8:-5] or "x").strip("/"), suffix, ext)
                newpath = os.path.join(os.path.dirname(old), newname)
            try:
                os.rename(old, newpath)
                done += 1
            except OSError as e:
                print("  跳过（路径过长/占用）: %s" % str(e)[:80])
                continue
        renamed[u] = os.path.relpath(newpath, ROOT).replace("\\", "/")

urlmap.update(renamed)
json.dump(urlmap, open(UM, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

PICD = os.path.join(BASE, "图片")
files = sorted(os.listdir(PICD))
print("重命名 %d 个文件 ｜ 目录现 %d 个" % (done, len(files)))
print("最长文件名 %d 字 ｜ 最长完整路径 %d 字符（上限 260）" % (
    max((len(f) for f in files), default=0),
    max((len(os.path.join(PICD, f)) for f in files), default=0)))
print("\n=== 示例（前 12 个）===")
for f in files[:12]:
    print("  " + (f[:100] + ("…" if len(f) > 100 else "")))
