# -*- coding: utf-8 -*-
r"""10 下载群相册：每个相册一个文件夹，按相册分类归档
   用法: python 10_download_albums.py [--index-only]
   产出: <ROOT>\<相册名>\NNNN_YYYYMMDD-HHMM_上传者.ext
         <ROOT>\_索引\<相册名>.json     （每张图的元数据）
         <ROOT>\_索引\相册总表.json
         <ROOT>\_下载日志.txt
"""
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

API = "http://127.0.0.1:3000"
TOKEN = open(r"E:\dsh work\napcat-token.txt", encoding="utf-8").read().strip()
GID = "752855970"
ROOT = r"E:\dsh work\冰室群相册"
IDX = os.path.join(ROOT, "_索引")
LOG = os.path.join(ROOT, "_下载日志.txt")
INDEX_ONLY = "--index-only" in sys.argv
os.makedirs(IDX, exist_ok=True)

BAD = re.compile(r'[\\/:*?"<>|\r\n\t]')


def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def call(action, **params):
    url = API + "/" + action
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + TOKEN})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.loads(r.read().decode("utf-8"))


def safe(s, n=60):
    s = BAD.sub("_", str(s or "")).strip() or "未命名"
    return s[:n]


def ts(t):
    try:
        return time.strftime("%Y%m%d-%H%M", time.localtime(int(t)))
    except Exception:
        return "00000000-0000"


def pick_url(media):
    """取分辨率最大的那张；视频则取 video.url"""
    v = media.get("video") or {}
    if v and (v.get("url") or v.get("play_url")):
        return (v.get("url") or v.get("play_url")), (v.get("width") or 0), (v.get("height") or 0), True
    cands = []
    for u in ((media.get("image") or {}).get("photo_url") or []):
        ur = u.get("url") or {}
        if ur.get("url"):
            cands.append((int(ur.get("width") or 0) * int(ur.get("height") or 0),
                          int(u.get("spec") or 0), ur.get("url")))
    if not cands:
        du = ((media.get("image") or {}).get("default_url") or {}).get("url")
        if du:
            return du, 0, 0, False
        return None, 0, 0, False
    cands.sort()
    return cands[-1][2], 0, 0, False


def uploader_of(m):
    up = m.get("uploader") or m.get("upload_user") or {}
    if isinstance(up, dict):
        return str(up.get("nick") or up.get("name") or up.get("uin") or "")
    return str(up or "")


# ───── 1. 相册总表（分页）─────
albums, attach, page = [], "", 0
while True:
    r = call("get_qun_album_list", group_id=GID, attach_info=attach) if attach else call("get_qun_album_list", group_id=GID)
    d = r.get("data") or {}
    albums += d.get("album_list") or []
    page += 1
    if not d.get("has_more") or not d.get("attach_info") or page > 10:
        break
    attach = d.get("attach_info")

log("相册总数 %d" % len(albums))
table = [{"album_id": a.get("album_id"), "name": a.get("name"),
          "upload_number": int(a.get("upload_number") or 0),
          "create_time": a.get("create_time"), "desc": (a.get("desc") or "").strip()} for a in albums]
json.dump(table, open(os.path.join(IDX, "相册总表.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for a in table:
    log("  %-30s 声称 %5d 张" % (a["name"], a["upload_number"]))

# ───── 2. 每个相册的媒体清单（分页）─────
allmedia = {}
for a in table:
    aid, name = a["album_id"], a["name"]
    items, att, p = [], "", 0
    while True:
        r = call("get_group_album_media_list", group_id=GID, album_id=aid, attach_info=att) if att else \
            call("get_group_album_media_list", group_id=GID, album_id=aid)
        d = r.get("data") or {}
        items += d.get("media_list") or []
        p += 1
        if not d.get("next_has_more") or not d.get("next_attach_info") or p > 200:
            break
        att = d.get("next_attach_info")
    recs = []
    for i, m in enumerate(items, 1):
        u, w, h, isv = pick_url(m)
        recs.append({"seq": i, "lloc": (m.get("image") or {}).get("lloc") or m.get("client_key"),
                     "url": u, "uploader": uploader_of(m), "upload_time": str(m.get("upload_time") or ""),
                     "type": m.get("type"), "is_video": isv, "file_size": m.get("file_size"),
                     "desc": (m.get("desc") or "")[:200]})
    allmedia[aid] = recs
    json.dump(recs, open(os.path.join(IDX, safe(name) + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    log("清单 %-30s 实取 %5d 张（声称 %d）%s" % (name, len(recs), a["upload_number"],
                                          "" if len(recs) == a["upload_number"] else "  ⚠ 不一致"))

TOTAL = sum(len(v) for v in allmedia.values())
log("媒体清单合计 %d 张" % TOTAL)
if INDEX_ONLY:
    log("--index-only：到此为止")
    sys.exit(0)

# ───── 3. 下载 ─────
MAGIC = [(b"\xff\xd8\xff", ".jpg"), (b"\x89PNG", ".png"), (b"GIF8", ".gif"), (b"RIFF", ".webp"), (b"\x00\x00\x00\x18ftyp", ".mp4")]
CT = {"image/jpeg": ".jpg", "image/jpg": ".jpg", "image/png": ".png", "image/gif": ".gif",
      "image/webp": ".webp", "video/mp4": ".mp4"}
ok = skip = fail = 0
bytes_total = 0
for a in table:
    aid, name = a["album_id"], a["name"]
    folder = os.path.join(ROOT, safe(name))
    os.makedirs(folder, exist_ok=True)
    have = set(os.listdir(folder))
    for rec in allmedia[aid]:
        if not rec["url"]:
            fail += 1
            continue
        stem = "%04d_%s_%s" % (rec["seq"], ts(rec["upload_time"]), safe(rec["uploader"], 16))
        if any(h.startswith(stem + ".") for h in have):
            skip += 1
            continue
        try:
            req = urllib.request.Request(rec["url"], headers={
                "User-Agent": "Mozilla/5.0", "Referer": "https://qun.qq.com/"})
            with urllib.request.urlopen(req, timeout=90) as r:
                data = r.read()
                ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            ext = CT.get(ctype)
            if not ext:
                for mg, e in MAGIC:
                    if data.startswith(mg):
                        ext = e
                        break
            ext = ext or ".jpg"
            p = os.path.join(folder, stem + ext)
            with open(p, "wb") as f:
                f.write(data)
            have.add(os.path.basename(p))
            ok += 1
            bytes_total += len(data)
            if ok % 25 == 0:
                log("  已下载 %d / %d（%.1f MB）" % (ok, TOTAL, bytes_total / 1048576))
        except Exception as e:
            fail += 1
            if fail <= 12:
                log("  [FAIL] %s #%d %s" % (name, rec["seq"], str(e)[:80]))
    log("相册完成 %-30s 目录 %d 个文件" % (name, len(os.listdir(folder))))

log("下载结束：成功 %d ｜ 已存在跳过 %d ｜ 失败 %d ｜ 合计 %.1f MB" % (ok, skip, fail, bytes_total / 1048576))
