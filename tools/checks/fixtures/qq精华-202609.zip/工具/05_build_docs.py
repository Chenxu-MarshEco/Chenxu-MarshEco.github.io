# -*- coding: utf-8 -*-
r"""05 生成文档：群精华_2026年9月.md / .html（内嵌图 + 时间轴 + 搜索）+ 人物名册_2026年9月.md
   规格沿革自 E:\dsh work\qq精华：人名规范化、正文与图片文字齐全、按时间轴分组。
"""
import json
import os
import re
import base64
import io
import datetime

from PIL import Image

ROOT = r"E:\dsh work\qq精华-202609"
GID = "752855970"
BASE = os.path.join(ROOT, "images", GID)

urlmap = json.load(open(os.path.join(BASE, "_urlmap.json"), encoding="utf-8"))
chat = json.load(open(os.path.join(BASE, "_chatshots.json"), encoding="utf-8"))
D = json.load(open(os.path.join(ROOT, "源数据_2026年9月.json"), encoding="utf-8"))
recs = D["records"]
GNAME = D.get("group_name") or "燃儿求开组"

PEOPLE = {
    "Raw": ["Raw", "梦之泪伤", "泪伤", "纯情op火辣辣", "梦游宅人纯情夜之部屋", "芋芋杀人大魔王",
            "大女主的狂吠之逼", "大女主的狂联之逼", "喜欢抗击恐惧之枷被你发现", "攻击速度+7",
            "为母则刚（地雷女）", "为母则刚", "煎扁肉", "LV100群主"],
    "花花": ["隰辰煦", "辰煦", "伤心小隰", "伤心小暝", "花花", "煦儿", "煦", "狮蝎厨一号", "爱是在路边尿尿"],
    "Sunf": ["ミスタ", "スタ", "Sunf", "Sf10492"],
    "虹星": ["亚卡莱特", "灯灯鬼灵灵", "穿衣服的猫猫"],
    "SSWTLZZ": ["SSWTLZZ", "SSW"],
    "Airo": ["ai.🚽👩▽🥩🕷️♀👩🏻", "ai.🚽👩▽🥩🕷️", "Airo"],
    "羽之颂": ["澄净羽之颂", "洗碗槽臭鱼", "𓆟小𓆞鱼", "羽毛笔1号", "愤怒小鳥", "愤怒小鸟"],
    "吉吉": ["彰吉吉", "Koishijiji", "吉弟八千慧"],
    "灵空天仪": ["幻想超级淫趴物语花园世界冰室"],
    "owq": ["629987827加群送少女", "努力成为阳角"],
    "沃伊德": ["沃伊德", "Void254", "世界的尽头"],
    "平铃": ["平铃"], "盾返": ["盾返with森林的香气"], "math": ["怨妇"],
    "伤感统领": ["弾幕狂蒐家の妄執", "盖長類最強の魔法使い", "需長類最强の魔法使"],
    "金色糖糕": ["金色糖糕"], "艾林森": ["鸡群意志"], "希尔": ["UDRA🐳HYA"],
}
PAIRS = sorted(((a, c) for c, als in PEOPLE.items() for a in als), key=lambda kv: -len(kv[0]))

BADGE = re.compile(r"LV\s*\d+|管理员|群主")
GRP = re.compile(r"[（(]\s*\d{1,4}\s*[）)]")
MCCHAT = re.compile(r"<[A-Za-z_][A-Za-z0-9_]{2,}>")
BADSIGN = re.compile(r"抖音|关注|粉丝|团购|点赞|开口跪|哔哩|bilibili|视频|直播|UNDERTALE|TeamViewer|"
                     r"Gemini|DeepSeek-V3|思考结果|装备详情|最高得分|ver 1\.|Version", re.I)

# 人工校正（本月只有 7 张图，逐张看过）：
#   完美对话 = #006 #011 #012 #027（真·群聊对话）
#   非对话   = #007（输入法联想截图） #016（鸟与果实照片） #023（LOL 战绩图）
FORCE_DIALOG = {"006", "011", "012", "027"}
FORCE_NOT_DIALOG = {"007", "016", "023"}


def canon(n):
    n = n or "?"
    for a, c in PAIRS:
        if a in n:
            return c
    return n


def to_dt(s):
    try:
        return datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
    except Exception:
        return datetime.datetime(1970, 1, 1)


def is_ai(t):
    if len(t) < 400:
        return False
    return sum(1 for m in ["**", "###", "感谢你的补充", "根据你提供", "同步后", "对话1", "对话2", "——"] if m in t) >= 2 or len(t) > 1200


def is_dialog(num):
    if num in FORCE_DIALOG:
        return True
    if num in FORCE_NOT_DIALOG:
        return False
    v = chat.get(num)
    if not v:
        return False
    t = "\n".join(v["lines"])
    if BADSIGN.search(t):
        return False
    qq_chat = bool(BADGE.search(t) or GRP.search(t))
    mc_chat = len(MCCHAT.findall(t)) >= 2
    return v["score"] >= 3 and (qq_chat or mc_chat)


def img_of(r):
    return next((urlmap.get(u) for u in (r.get("images") or []) if urlmap.get(u)), "")


texts, ais, dialogs = [], [], []
people = {}
for r in recs:
    sn = r.get("sender_nick") or ""
    t = (r.get("text") or "").strip()
    num = "%03d" % r["index"]
    d = to_dt(r["time"])
    rel = img_of(r)
    who = canon(sn)
    st = people.setdefault(who, {"n": 0, "img": 0, "first": d, "last": d, "aks": set()})
    st["n"] += 1
    st["img"] += 1 if rel else 0
    st["first"] = min(st["first"], d)
    st["last"] = max(st["last"], d)
    st["aks"].add(sn)

    if is_dialog(num):
        v = chat[num]
        lines = [l.strip() for l in v["lines"] if not re.fullmatch(r"[A-Za-z]", l.strip())]
        body = "\n".join("- " + l for l in lines) + "\n\n*（本条为 OCR 自动转录，可能有个别错字）*"
        dialogs.append((d, r["index"], body, rel, t if t and t != "[图片]" else "", who))
        continue
    if t in ("", "[图片]") and not rel:
        continue
    item = (d, who, t or "（纯图片）", [urlmap[u] for u in (r.get("images") or []) if urlmap.get(u)], r["index"])
    (ais if is_ai(t) else texts).append(item)

TOT, TOTAI, TOTD = len(texts), len(ais), len(dialogs)
NIMG = len([f for f in os.listdir(os.path.join(BASE, "图片")) if os.path.isfile(os.path.join(BASE, "图片", f))])
DAYS = sorted({t[0].strftime("%Y-%m-%d") for t in texts + ais})
DLGDAY = {}
for _d, _idx, _b, _r, _c, _w in dialogs:
    DLGDAY.setdefault(_d.strftime("%Y-%m-%d"), _idx)
ALLDAYS = sorted(set(DAYS) | set(DLGDAY))


def day_anchor(dd):
    """有正文的天锚到当天小节；只有完美对话的天锚到那段对话"""
    return ("#d" + dd.replace("-", "")) if dd in DAYS else ("#dlg%03d" % DLGDAY[dd])


def day_counts(dd):
    n = sum(1 for x in texts + ais if x[0].strftime("%Y-%m-%d") == dd)
    m = sum(1 for x in dialogs if x[0].strftime("%Y-%m-%d") == dd)
    return n, m

print("条数：文字 %d ｜ AI %d ｜ 完美对话 %d ｜ 图片 %d 张 ｜ 有内容的天数 %d" % (TOT, TOTAI, TOTD, NIMG, len(DAYS)))
print("人物 %d 位" % len(people))

WD = "一二三四五六日"
MONTH_CN = "%s 年 %s 月" % (recs[0]["time"][:4], int(recs[0]["time"][5:7]))


def day_head(d):
    return "%s · 周%s" % (d.strftime("%Y-%m-%d"), WD[d.weekday()])


# ───────── MD ─────────
M = ["# 冰室群精华 · %s" % MONTH_CN, "",
     "> 群 `%s`（%s ｜ 旧名：冰室）" % (GID, GNAME),
     "> 范围：%s ~ %s ｜ 共 **%d** 条 ｜ 图片 %d 张 ｜ 完美对话 %d 段 ｜ 人物 %d 位" % (
         recs[0]["time"][:10], recs[-1]["time"][:10], TOT + TOTAI + TOTD, NIMG, TOTD, len(people)),
     "", "## 目录", ""]
for dd in ALLDAYS:
    n, m = day_counts(dd)
    tail = "　%d 条" % n if n else ""
    tail += "　🗨️ %d 段" % m if m else ""
    M.append("- [%s](%s)%s" % (day_head(datetime.datetime.strptime(dd, "%Y-%m-%d")), day_anchor(dd), tail))
M += ["- [🗨️ 完美对话（%d）](#dialogs)" % TOTD,
      "- [🧑 人物名册（%d 人）](#people)" % len(people), "", "---"]

for dd in DAYS:
    day = datetime.datetime.strptime(dd, "%Y-%m-%d")
    M += ["", "<a id='d%s'></a>" % dd.replace("-", ""), "# %s" % day_head(day), ""]
    for d, who, t, imgs, idx in sorted([x for x in texts + ais if x[0].strftime("%Y-%m-%d") == dd]):
        tag = "　🤖" if (d, who, t, imgs, idx) in ais else ""
        M += ["**%s　%s**%s" % (who, d.strftime("%Y-%m-%d %H:%M"), tag), ""]
        for line in t.split("\n"):
            M.append(("> " + line) if line.strip() else ">")
        M.append("")
        for u in imgs:
            M += ["![图片](%s)" % u, ""]

M += ["", "---", "", "<a id='dialogs'></a>", "# 🗨️ 完美对话（%d 段）" % TOTD, "",
      "> 群聊截图类精华，图中文字已由 OCR 逐行转录。", ""]
for d, idx, body, rel, cap, who in sorted(dialogs):
    M += ["<a id='dlg%03d'></a>" % idx, "### 🗨️ %s　#%03d　%s" % (d.strftime("%Y-%m-%d %H:%M"), idx, who), ""]
    if cap:
        M += ["> " + cap, ""]
    if rel:
        M += ["![完美对话](%s)" % rel, ""]
    M += [body, ""]

M += ["", "---", "", "<a id='people'></a>", "# 🧑 人物名册 · %s" % MONTH_CN, "",
      "| 规范名 | 精华 | 图片 | 时间跨度 | 马甲 |", "|---|---|---|---|---|"]
for who, st in sorted(people.items(), key=lambda kv: -kv[1]["n"]):
    aks = "、".join(sorted(st["aks"]))
    M.append("| **%s** | %d | %d | %s → %s | %s |" % (
        who, st["n"], st["img"], st["first"].strftime("%Y-%m-%d"), st["last"].strftime("%Y-%m-%d"), aks))
M += ["", "共 %d 位（本月有精华记录）" % len(people), ""]
open(os.path.join(ROOT, "群精华_2026年9月.md"), "w", encoding="utf-8").write("\n".join(M))

R = ["# 人物名册 · %s（终版）" % MONTH_CN, "", "| 规范名 | 精华 | 图片 | 时间跨度 | 全部马甲 |", "|---|---|---|---|---|"]
for who, st in sorted(people.items(), key=lambda kv: -kv[1]["n"]):
    R.append("| **%s** | %d | %d | %s → %s | %s |" % (
        who, st["n"], st["img"], st["first"].strftime("%Y-%m-%d"), st["last"].strftime("%Y-%m-%d"),
        "、".join(sorted(st["aks"]))))
R += ["", "共 %d 位（本月有精华记录）" % len(people), ""]
open(os.path.join(ROOT, "人物名册_2026年9月.md"), "w", encoding="utf-8").write("\n".join(R))

# ───────── HTML ─────────
def data_uri(rel, maxw=520):
    fp = os.path.join(ROOT, rel.replace("/", os.sep))
    if not os.path.exists(fp):
        return None
    try:
        im = Image.open(fp)
        if im.width > maxw:
            im = im.resize((maxw, int(im.height * maxw / im.width)), Image.LANCZOS)
        buf = io.BytesIO()
        im.convert("RGB").save(buf, "JPEG", quality=82)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception:
        return None


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


CSS = ("<style>html{scroll-behavior:smooth}body{margin:0;padding:0;font:16px/1.85 -apple-system,'Microsoft YaHei',sans-serif;color:#222}"
       ".layout{display:flex;gap:2.5rem;align-items:flex-start;max-width:1180px;margin:0 auto;padding:1.6rem 1.5rem 5rem}"
       "aside{flex:0 0 210px;position:sticky;top:1.6rem;font-size:.92em}"
       "aside .ttl{color:#999;font-size:.82em;letter-spacing:.1em;margin:.9rem 0 .6rem}"
       "aside a{display:block;text-decoration:none;color:#2b6cb0;padding:.32rem .55rem;border-left:3px solid transparent;border-radius:0 4px 4px 0;line-height:1.4}"
       "aside a span{display:block;color:#aaa;font-size:.76em}aside a:hover{background:#f2f7fd}"
       "aside a.on{border-left-color:#2b6cb0;background:#eef5fd;font-weight:600;color:#1a4e8a}"
       "main{flex:1 1 auto;min-width:0}h1{border-bottom:2px solid #ddd;padding-bottom:.3rem;margin-top:3rem;scroll-margin-top:2rem}"
       "h1:first-child{margin-top:0}h2,h3{margin-top:2rem}h3{color:#444}h4{color:#555;margin-top:1.6rem}"
       "blockquote{margin:.4rem 0;padding:.55rem .9rem;background:#f6f6f6;border-left:4px solid #bbb;border-radius:4px;white-space:pre-wrap}"
       "img{max-width:100%;border:1px solid #ddd;border-radius:6px;margin:.6rem 0;display:block}"
       "hr{margin:2.5rem 0;border:0;border-top:1px dashed #ccc}"
       ".search{margin-bottom:1rem}.search input{width:100%;box-sizing:border-box;padding:.45rem .6rem;border:1px solid #d5d5d5;border-radius:6px;font-size:.92em}"
       ".hit{color:#2b6cb0;font-size:.8em;min-height:1.1em;margin:.3rem 0}"
       "table{border-collapse:collapse;width:100%;font-size:.92em}td,th{border:1px solid #e2e2e2;padding:.35rem .55rem;text-align:left}th{background:#fafafa}"
       "@media(max-width:880px){.layout{flex-direction:column}aside{position:static;flex:none;width:100%}"
       "aside a{border-left:0;border-bottom:2px solid transparent;padding:.2rem .5rem}}"
       "</style>")

H = ["<!doctype html><html lang='zh'><head><meta charset='utf-8'><title>冰室群精华 · %s</title>" % MONTH_CN, CSS,
     "</head><body><div class='layout'><aside id='top'>",
     "<div class='search'><input id='q' type='search' placeholder='搜索关键词…（按 / 聚焦）'><div id='hit' class='hit'></div></div>",
     "<div class='ttl'>时间轴</div>"]
for dd in ALLDAYS:
    n, m = day_counts(dd)
    sub = ("%d 条" % n) if n else ""
    sub += (" 🗨️%d" % m) if m else ""
    H.append("<a href='%s' data-era='%s'>%s<span>%s</span></a>" % (day_anchor(dd), dd, dd[5:], sub))
H += ["<div class='ttl'>其他</div>",
      "<a href='#dialogs'>🗨️ 完美对话<span>%d 段</span></a>" % TOTD,
      "<a href='#people'>🧑 人物名册<span>%d 人</span></a>" % len(people),
      "</aside><main>",
      "<h1>冰室群精华 · %s</h1>" % MONTH_CN,
      "<p>群 <code>%s</code>（%s ｜ 旧名：冰室）<br>%s ~ %s ｜ 共 %d 条 ｜ 图片 %d 张 ｜ 人物 %d 位</p>" % (
          GID, GNAME, recs[0]["time"][:10], recs[-1]["time"][:10], TOT + TOTAI + TOTD, NIMG, len(people))]

cnt = 0
for dd in DAYS:
    day = datetime.datetime.strptime(dd, "%Y-%m-%d")
    H.append("<h1 id='d%s'>%s</h1>" % (dd.replace("-", ""), day_head(day)))
    for d, who, t, imgs, idx in sorted([x for x in texts + ais if x[0].strftime("%Y-%m-%d") == dd]):
        tag = "　🤖" if (d, who, t, imgs, idx) in ais else ""
        H.append("<div class='item'><p><b>%s　%s</b>%s</p>" % (esc(who), d.strftime("%Y-%m-%d %H:%M"), tag))
        if t and t != "（纯图片）":
            H.append("<blockquote>%s</blockquote>" % esc(t))
        for u in imgs:
            uri = data_uri(u)
            if uri:
                cnt += 1
                H.append("<img src='%s'>" % uri)
        H.append("</div>")

H.append("<h1 id='dialogs'>🗨️ 完美对话（%d 段）</h1>" % TOTD)
H.append("<p style='color:#888'>群聊截图类精华，图中文字已由 OCR 逐行转录。</p>")
for d, idx, body, rel, cap, who in sorted(dialogs):
    H.append("<div class='item' id='dlg%03d'><h4>🗨️ %s　#%03d　%s</h4>" % (idx, d.strftime("%Y-%m-%d %H:%M"), idx, esc(who)))
    if cap:
        H.append("<blockquote>%s</blockquote>" % esc(cap))
    if rel:
        uri = data_uri(rel)
        if uri:
            cnt += 1
            H.append("<img src='%s'>" % uri)
    H.append("<blockquote>%s</blockquote></div>" % esc(body))

H.append("<h1 id='people'>🧑 人物名册 · %s</h1>" % MONTH_CN)
H.append("<table><tr><th>规范名</th><th>精华</th><th>图片</th><th>时间跨度</th><th>马甲</th></tr>")
for who, st in sorted(people.items(), key=lambda kv: -kv[1]["n"]):
    H.append("<tr><td><b>%s</b></td><td>%d</td><td>%d</td><td>%s → %s</td><td>%s</td></tr>" % (
        esc(who), st["n"], st["img"], st["first"].strftime("%Y-%m-%d"), st["last"].strftime("%Y-%m-%d"),
        esc("、".join(sorted(st["aks"])))))
H.append("</table><p>共 %d 位（本月有精华记录）</p>" % len(people))
H.append("</main></div>")

H.append("""<script>
(function(){
  var qEl=document.getElementById('q'), hitEl=document.getElementById('hit');
  var items=[].slice.call(document.querySelectorAll('.item'));
  function run(){
    var s=(qEl.value||'').trim().toLowerCase(), n=0;
    for(var i=0;i<items.length;i++){
      var it=items[i];
      var ok=(!s||it.textContent.toLowerCase().indexOf(s)>=0);
      it.style.display=ok?'':'none';
      if(ok){n++;}
    }
    hitEl.textContent=s?(n+' 条匹配'):'';
  }
  qEl.addEventListener('input',run);
  document.addEventListener('keydown',function(e){
    if(e.key==='/' && document.activeElement!==qEl){e.preventDefault();qEl.focus();}
  });
  var links=[].slice.call(document.querySelectorAll("aside a")), heads=[].slice.call(document.querySelectorAll("h1[id]"));
  function spy(){var k=0;heads.forEach(function(h,i){if(h.getBoundingClientRect().top<=120)k=i;});
    links.forEach(function(a,i){a.classList.toggle("on",i===k);});}
  addEventListener("scroll",spy,{passive:true});spy();
})();
</script>""")
H.append("</body></html>")

html = os.path.join(ROOT, "群精华_2026年9月.html")
open(html, "w", encoding="utf-8").write("\n".join(H))

# script 语法自检
scr = re.findall(r"<script>(.*?)</script>", "".join(H), flags=re.S)
open(os.path.join(ROOT, "_work", "_check.js"), "w", encoding="utf-8").write("\n;\n".join(scr))
print("\n产出：")
print("  群精华_2026年9月.md        %.0f KB" % (os.path.getsize(os.path.join(ROOT, "群精华_2026年9月.md")) / 1024))
print("  人物名册_2026年9月.md      %.0f KB" % (os.path.getsize(os.path.join(ROOT, "人物名册_2026年9月.md")) / 1024))
print("  群精华_2026年9月.html      %.1f MB（内嵌 %d 张 ｜ script 块 %d）" % (
    os.path.getsize(html) / 1048576, cnt, len(scr)))
