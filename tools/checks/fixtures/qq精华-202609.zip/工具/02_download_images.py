# -*- coding: utf-8 -*-
"""02 下载：把本月精华里的图片全部下回本地（保持原始名 编号_昵称_hash.ext）
   并建立 _urlmap.json（URL → 相对路径），供后续重命名/生成文档使用。
"""
import json
import os
import hashlib
import urllib.request

ROOT = r"E:\dsh work\qq精华-202609"
GID = "752855970"
BASE = os.path.join(ROOT, "images", GID)
PICD = os.path.join(BASE, "图片")
os.makedirs(PICD, exist_ok=True)

d = json.load(open(os.path.join(ROOT, "源数据_2026年9月.json"), encoding="utf-8"))
recs = d["records"]
UM = os.path.join(BASE, "_urlmap.json")
urlmap = json.load(open(UM, encoding="utf-8")) if os.path.exists(UM) else {}

ok = skip = fail = 0
total = 0
for r in recs:
    idx = "%03d" % r["index"]
    for u in (r.get("images") or []):
        if not u:
            continue
        if u in urlmap and os.path.exists(os.path.join(ROOT, urlmap[u].replace("/", os.sep))):
            skip += 1
            continue
        h = hashlib.md5(u.encode()).hexdigest()[:10]
        ext = ".jpg"
        for e in (".png", ".jpeg", ".jpg", ".gif", ".webp", ".bmp"):
            if u.lower().split("?")[0].endswith(e):
                ext = e
                break
        nick = (r.get("sender_nick") or "x")[:12].replace("/", "_").replace("\\", "_")
        dest = os.path.join(PICD, "%s_%s_%s%s" % (idx, nick, h, ext))
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = resp.read()
            with open(dest, "wb") as f:
                f.write(data)
            urlmap[u] = os.path.relpath(dest, ROOT).replace("\\", "/")
            ok += 1
            total += len(data)
        except Exception as e:
            fail += 1
            print("  [FAIL] #%s %s" % (idx, str(e)[:90]))

json.dump(urlmap, open(UM, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
files = [f for f in os.listdir(PICD) if os.path.isfile(os.path.join(PICD, f))]
print("新下载 %d 张（%.1f MB）｜ 已存在跳过 %d ｜ 失败 %d" % (ok, total / 1048576, skip, fail))
print("图片目录共 %d 个文件 → %s" % (len(files), PICD))
print("_urlmap.json 记录 %d 条映射" % len(urlmap))
