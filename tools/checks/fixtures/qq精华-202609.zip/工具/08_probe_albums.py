# -*- coding: utf-8 -*-
r"""08 探测：群相册列表 + 每个相册的媒体数"""
import json
import urllib.parse
import urllib.request

API = "http://127.0.0.1:3000"
TOKEN = open(r"E:\dsh work\napcat-token.txt", encoding="utf-8").read().strip()
GID = "752855970"


def call(action, **params):
    url = API + "/" + action
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + TOKEN})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode("utf-8"))


res = call("get_qun_album_list", group_id=GID)
print("status=%s retcode=%s message=%s" % (res.get("status"), res.get("retcode"), res.get("message")))
data = res.get("data") or {}
print("顶层键:", list(data.keys()))
al = data.get("album_list")
if al is None and isinstance(data, list):
    al = data
print("相册数:", len(al or []))
if al:
    print("第一项字段:", list(al[0].keys()))
    print(json.dumps(al[0], ensure_ascii=False, indent=1)[:1200])
    print()
    for a in al:
        aid = a.get("album_id") or a.get("id")
        nm = a.get("album_name") or a.get("name")
        extra = {k: v for k, v in a.items() if k not in ("album_id", "album_name", "id", "name")}
        print("  %-28s %s" % (aid, nm))
        print("      %s" % json.dumps(extra, ensure_ascii=False)[:300])
