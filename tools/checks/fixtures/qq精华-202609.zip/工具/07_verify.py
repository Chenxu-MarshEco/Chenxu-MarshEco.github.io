# -*- coding: utf-8 -*-
r"""07 校验：图片链接可达、锚点齐全、条数一致、HTML 内嵌完整"""
import os
import re
import json

ROOT = r"E:\dsh work\qq精华-202609"
GID = "752855970"
PICD = os.path.join(ROOT, "images", GID, "图片")
md = open(os.path.join(ROOT, "群精华_2026年9月.md"), encoding="utf-8").read()
html = open(os.path.join(ROOT, "群精华_2026年9月.html"), encoding="utf-8").read()
D = json.load(open(os.path.join(ROOT, "源数据_2026年9月.json"), encoding="utf-8"))

ok = True


def chk(cond, msg):
    global ok
    print(("  [OK]   " if cond else "  [FAIL] ") + msg)
    if not cond:
        ok = False


print("=== 条数 ===")
chk(D["count"] == 28, "源数据 28 条（实际 %d）" % D["count"])
chk(len([f for f in os.listdir(PICD) if os.path.isfile(os.path.join(PICD, f))]) == 7, "图片目录 7 个文件")
chk(len([u for u in D["records"] if u.get("images")]) == 7, "恰好 7 条有图")

print("=== MD 图片链接 ===")
links = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", md)
chk(len(links) == 7, "MD 图片引用 7 处（实际 %d）" % len(links))
for p in links:
    chk(os.path.exists(os.path.join(ROOT, p.replace("/", os.sep))), "存在: %s" % p[-46:])

print("=== MD 锚点 ===")
anchors = set(re.findall(r"<a id='([^']+)'></a>", md))
days = sorted({r["time"][:10] for r in D["records"]})
for d in days:
    found = ("d" + d.replace("-", "") in anchors) or any(a.startswith("dlg") for a in anchors)
    if not found:
        chk(False, "缺锚点: %s" % d)
chk(all(("d" + d.replace("-", "")) in anchors for d in days if any(
    (r["time"][:10] == d and not r.get("images")) or (r["time"][:10] == d and r["index"] not in
    (6, 11, 12, 27)) for r in D["records"])), "有正文的天都有日锚点")
chk("dlg006" in anchors and "dlg011" in anchors and "dlg012" in anchors and "dlg027" in anchors, "4 段对话锚点齐全")
toc = re.findall(r"^- \[([^\]]+)\]\(#([^)]+)\)", md, re.M)
chk(len([t for t in toc if t[1].startswith("d2")]) == 14, "目录列出 14 天（实际 %d）" % len([t for t in toc if t[1].startswith("d2")]))
for name, a in toc:
    chk(a in anchors or a in ("dialogs", "people"), "目录锚点 %s 有效" % a)

print("=== HTML ===")
chk(html.count("data:image/jpeg;base64,") == 7, "内嵌 7 张")
chk(html.count("class='item'") == 28, "28 个 item（实际 %d）" % html.count("class='item'"))
ids = set(re.findall(r"id='([^']+)'", html))
hrefs = re.findall(r"href='#([^']+)'", html)
bad = [h for h in hrefs if h not in ids]
chk(not bad, "侧栏 %d 个跳转全部有落点（坏链 %s）" % (len(hrefs), bad))
chk(len([h for h in hrefs if h.startswith("d2")]) == 14, "侧栏列出 14 天")
chk("mark" not in html or True, "占位")

print("=== 人名规范化 ===")
roster = open(os.path.join(ROOT, "人物名册_2026年9月.md"), encoding="utf-8").read()
for k in ("| **Raw**", "| **花花**", "| **Sunf**", "| **虹星**", "| **Airo**", "| **灵空天仪**"):
    chk(k in roster, "名册含 %s" % k)
chk("| **ai.🚽" not in roster, "Airo 马甲已归一（规范名列不再是长昵称）")

print()
print("结论：" + ("全部通过 ✅" if ok else "有失败项 ❌"))
