# -*- coding: utf-8 -*-
r"""01 抓取：调 NapCat(OneBot 11) get_essence_msg_list 拉群精华，筛出 2026 年 9 月

用法: python 01_export_essence.py
产出: <ROOT>\_work\原始精华_全量.json      （该群全部精华，存档用）
      <ROOT>\源数据_2026年9月.json          （本月记录，编号重排）
      <ROOT>\群精华_原始_2026年9月.md       （含图片 URL 的原始清单，便于核对）
"""
import json
import os
import sys
import datetime
import urllib.parse
import urllib.request

API = "http://127.0.0.1:3000"
TOKEN = open(r"E:\dsh work\napcat-token.txt", encoding="utf-8").read().strip()
GID = "752855970"
MONTH = "2026-09"
ROOT = r"E:\dsh work\qq精华-202609"
WORK = os.path.join(ROOT, "_work")
os.makedirs(WORK, exist_ok=True)


def call(action, **params):
    url = API + "/" + action
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + TOKEN})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode("utf-8"))


def parse_segments(segs):
    parts, images = [], []
    for seg in segs or []:
        t = (seg or {}).get("type")
        d = (seg or {}).get("data") or {}
        if t == "text":
            parts.append(str(d.get("text", "")))
        elif t == "image":
            url = d.get("url") or d.get("file") or ""
            images.append(url)
            parts.append("[图片]")
        elif t == "face":
            parts.append("[表情]")
        elif t == "at":
            parts.append("@" + str(d.get("qq", "")))
        elif t == "reply":
            parts.append("[回复]")
        elif t == "file":
            parts.append("[文件: %s]" % d.get("file", ""))
        elif t == "video":
            parts.append("[视频]")
        elif t == "forward":
            parts.append("[合并转发]")
        else:
            parts.append("[%s]" % t)
    return "".join(parts).strip(), images


def ts(t):
    try:
        return datetime.datetime.fromtimestamp(int(t)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(t)


def main():
    info = call("get_login_info").get("data") or {}
    print("已登录: %s（%s）" % (info.get("nickname"), info.get("user_id")))
    try:
        gname = (call("get_group_info", group_id=GID).get("data") or {}).get("group_name", "")
    except Exception as e:
        gname = ""
        print("群名获取失败: %s" % e)

    raw = call("get_essence_msg_list", group_id=GID).get("data") or []
    print("群 %s（%s）精华全量: %d 条" % (GID, gname, len(raw)))
    json.dump({"group_id": GID, "group_name": gname, "fetched_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
               "total": len(raw), "raw": raw},
              open(os.path.join(WORK, "原始精华_全量.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    recs = []
    for item in raw:
        text, images = parse_segments(item.get("content") or item.get("message"))
        t_op = ts(item.get("operator_time")) if item.get("operator_time") else ""
        t_msg = ts(item.get("message_time")) if item.get("message_time") else ""
        t_show = t_msg or t_op
        recs.append({
            "sender_nick": item.get("sender_nick", ""),
            "sender_id": item.get("sender_id", ""),
            "operator_nick": item.get("operator_nick", ""),
            "time": t_show,
            "operator_time": t_op,
            "message_id": item.get("message_id"),
            "text": text,
            "images": images,
        })

    inmonth = [r for r in recs if (r["time"] or "").startswith(MONTH)]
    inmonth.sort(key=lambda r: r["time"])          # 旧 → 新
    for i, r in enumerate(inmonth, 1):
        r["index"] = i
    print("其中 %s 共 %d 条（无图 %d ｜ 有图 %d ｜ 图片总数 %d）" % (
        MONTH, len(inmonth),
        sum(1 for r in inmonth if not r["images"]),
        sum(1 for r in inmonth if r["images"]),
        sum(len(r["images"]) for r in inmonth)))
    if not inmonth:
        print("!! 本月没有精华，检查月份或群号")
        return 1

    json.dump({"group_id": GID, "group_name": gname, "month": MONTH,
               "exported_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
               "count": len(inmonth), "records": inmonth},
              open(os.path.join(ROOT, "源数据_2026年9月.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    L = ["# 群精华（原始清单）：%s" % gname, "",
         "- 群号：`%s`｜月份：%s｜条数：%d" % (GID, MONTH, len(inmonth)),
         "- 导出时间：%s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
         "- 来源：QQ 群精华（NapCat / OneBot `get_essence_msg_list`）", "", "---", ""]
    for r in inmonth:
        L += ["## %d. %s" % (r["index"], r["sender_nick"] or r["sender_id"]), "",
              "- 时间：%s" % r["time"],
              "- QQ：`%s`" % r["sender_id"],
              "- 设为精华：%s" % r["operator_nick"], ""]
        for line in (r["text"] or "(无文本内容)").splitlines() or [""]:
            L.append("> " + line)
        L.append("")
        for u in r["images"]:
            L += ["![图片](%s)" % u, ""]
        L += ["---", ""]
    open(os.path.join(ROOT, "群精华_原始_2026年9月.md"), "w", encoding="utf-8").write("\n".join(L))

    print("\n=== 按人统计（本月条数）===")
    cnt = {}
    for r in inmonth:
        cnt[r["sender_nick"]] = cnt.get(r["sender_nick"], 0) + 1
    for k, v in sorted(cnt.items(), key=lambda kv: -kv[1]):
        print("  %-32s %d" % (k[:32], v))
    print("\n产出：")
    print("  %s" % os.path.join(ROOT, "源数据_2026年9月.json"))
    print("  %s" % os.path.join(ROOT, "群精华_原始_2026年9月.md"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
