# -*- coding: utf-8 -*-
"""03 OCR：对本月全部精华图片做文字识别，产出 _chatshots.json
   —— 每张图：文件名、OCR 行、聊天截图判定分。
"""
import os
import re
import json

from rapidocr_onnxruntime import RapidOCR

ROOT = r"E:\dsh work\qq精华-202609"
GID = "752855970"
BASE = os.path.join(ROOT, "images", GID)
PICD = os.path.join(BASE, "图片")
OUT = os.path.join(BASE, "_chatshots.json")

CHAT_UI = ["消息", "撤回", "群聊", "发送", "表情", "聊天记录", "复制", "转发", "引用", "在线", "图片"]

engine = RapidOCR()
files = [f for f in sorted(os.listdir(PICD)) if os.path.isfile(os.path.join(PICD, f))]
print("待识别 %d 张" % len(files))

res = {}
for i, f in enumerate(files, 1):
    p = os.path.join(PICD, f)
    try:
        r, _ = engine(p)
    except Exception as e:
        r = None
        print("  [OCR FAIL] %s: %s" % (f[:40], str(e)[:60]))
    lines = [x[1].strip() for x in (r or []) if x and len(x) > 1 and x[1].strip()]
    text = "\n".join(lines)
    short = [l for l in lines if 1 <= len(l) <= 22]

    score = 0
    if re.search(r"LV\s*\d+", text):
        score += 3
    if re.search(r"(管理员|群主)", text):
        score += 2
    score += sum(2 for u in CHAT_UI if u in text)
    if re.search(r"[（(]\s*\d{1,4}\s*[）)]", text):
        score += 2
    if lines and len(lines) >= 4 and len(short) / len(lines) > 0.7:
        score += 2
    if len(lines) >= 6 and len(short) >= 4:
        score += 1
    if len(lines) <= 2 and max((len(l) for l in lines), default=0) > 40:
        score -= 3

    res[f.split("_")[0]] = {"file": f, "score": score, "is_chat": score >= 3, "lines": lines}
    if i % 20 == 0:
        print("  ...%d/%d" % (i, len(files)))

json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("\nOCR 完成：%d 张 → %s" % (len(res), OUT))
print("有文字 %d 张 ｜ 无文字 %d 张 ｜ 判定为聊天截图 %d 张" % (
    sum(1 for v in res.values() if v["lines"]),
    sum(1 for v in res.values() if not v["lines"]),
    sum(1 for v in res.values() if v["is_chat"])))
