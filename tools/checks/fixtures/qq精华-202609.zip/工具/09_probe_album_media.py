# -*- coding: utf-8 -*-
r"""09 试抓：拿一个小组验证媒体列表结构 + 图片 URL 是否可直接下载"""
import json
import os
import urllib.parse
import urllib.request

API = "http://127.0.0.1:3000"
TOKEN = open(r"E:\dsh work\napcat-token.txt", encoding="utf-8").read().strip()
GID = "752855970"
ALBUM = "V62qHCTs3kSiGR1zQh7d36015n4Rrko9"          # 人壳之家（4 张）
OUT = r"E:\dsh work\冰室群相册\_试抓"
os.makedirs(OUT, exist_ok=True)


def call(action, **params):
    url = API + "/" + action
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + TOKEN})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode("utf-8"))


res = call("get_group_album_media_list", group_id=GID, album_id=ALBUM)
print("status=%s retcode=%s msg=%s" % (res.get("status"), res.get("retcode"), res.get("message")))
d = res.get("data") or {}
print("顶层键:", list(d.keys()))
lst = d.get("media_list") or d.get("media") or []
print("本页媒体数:", len(lst), "｜ has_more:", d.get("has_more"), "｜ attach_info:", str(d.get("attach_info"))[:40])
if not lst:
    print(json.dumps(res, ensure_ascii=False)[:1500])
    raise SystemExit(0)

m = lst[0]
print("媒体字段:", list(m.keys()))
print(json.dumps({k: v for k, v in m.items() if k != "photo_url"}, ensure_ascii=False, indent=1)[:1500])
print()
print("photo_url specs:", [(u.get("spec"), (u.get("url") or {}).get("url", "")[:60]) for u in (m.get("photo_url") or [])][:6])

# 挑最大 spec 下载一张
best = None
for u in (m.get("photo_url") or []):
    ur = (u.get("url") or {})
    if ur.get("url") and (best is None or (u.get("spec") or 0) > (best[0] or 0)):
        best = (u.get("spec"), ur.get("url"), ur.get("width"), ur.get("height"))
print("\n挑中 spec=%s %sx%s" % (best[0], best[2], best[3]))
print(best[1][:160])

req = urllib.request.Request(best[1], headers={"User-Agent": "Mozilla/5.0", "Referer": "https://qun.qq.com/"})
try:
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
        print("HTTP %s ｜ Content-Type=%s ｜ %d 字节" % (r.status, r.headers.get("Content-Type"), len(data)))
    p = os.path.join(OUT, "test_%s.jpg" % best[0])
    open(p, "wb").write(data)
    print("已保存:", p)
except Exception as e:
    print("下载失败:", e)
